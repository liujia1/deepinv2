function y=apply_Q2(alpha,beta,x)
% Applies matrix Q2


x1=x(1:length(x)/2);
x2=x(length(x)/2+1:end);

y=[alpha*x1+beta*x2;beta*x1+alpha*x2];

