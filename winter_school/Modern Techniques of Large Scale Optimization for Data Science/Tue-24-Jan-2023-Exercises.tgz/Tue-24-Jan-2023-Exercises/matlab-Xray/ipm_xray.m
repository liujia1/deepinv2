function [g]=ipm_xray(fA,fAt,m,n,alpha,beta,CS)
% % % % % % % % % % % % % % % % % % % % % % % % % % %
% IPM for xray tomography
%
% fA:   function that applies A 
% fAt:  function that applies A'
% m:    measurement vector
% n:    size of g
% alpha,beta: regularization parameters
% CS:   struct with coefficients
%       CS.e11 = alpha+(c11^2+c21^2)*rho
%       CS.e12 = beta+(c11*c12+c21*c22)*rho
%       CS.e22 = alpha+(c12^2+c22^2)*rho
%       where rho is the mean diagonal element 
%       of A'*A
%
% % % % % % % % % % % % % % % % % % % % % % % % % % %

%% Initialize
%initialization
g=1e3*ones(n,1);
s=1e3*ones(n,1);

iter = 0;
alpha_g = 0;
alpha_s = 0;
IPM_time=0;
iterPCG=0;
Atm=fAt(m);

%parameters
tol=1e-6;
maxit=500;
sigma1   = 0.5;
sigmamin = 0.05;
sigmamax = 0.95;
rho = 0.995;

%% Iteration
% % % % % % % % % % % % % % % % % % % % % % % % % %
% Newton system
%   [ Q -I ] (dg) = r1
%   [ S  G ] (ds) = r2
%
% Q=A'*A+Q2
% r1=A'*m+s-Q*g
% r2=sigma*mu*e-g.*s
% mu=g'*s/n;
% % % % % % % % % % % % % % % % % % % % % % % % % %  

nAtm=norm(Atm);
r1 = Atm+s-fAt(fA(g))-apply_Q2(alpha,beta,g);
mu = (g'*s)/n;


%Compute Q for small sizes
if n<=2048
    Q = explicit_Q(n,m,CS,alpha,beta);
end



fprintf('\nIPM_iter    infeas       mu     PCG_iter    Cond NE\n')


while iter<maxit
    
    if norm(r1)/norm(Atm)<tol && mu<tol
       fprintf('\n*** Optimal solution found ***\n')
       break
    end
    
    iter=iter+1;
    if iter == 1
      sigma = sigma1;
    else
      sigma = max(1-alpha_g,1-alpha_s)^5;
    end
    sigma = min(sigma,sigmamax);
    sigma = max(sigma,sigmamin);
    r2 = sigma*mu*ones(n,1) - g.*s;
    
    %% Solve normal equations
    % % % % % % % % % % % % % % % % % % % % % % % % % %
    % Normal equations
    %
    % (Q+G^-1*S)*dg = r1+G^-1*r2
    % ds = G^-1*(r2-S*dg)
    %
    % % % % % % % % % % % % % % % % % % % % % % % % % %
    
    tic
    rhs=r1+r2./g;

    % PCG IS CALLED HERE    <==============

    % Run the PCG without preconditioner and observe what happens.
    % Then, run the PCG using the function apply_prec as preconditioner.
    % Can you figure out how the preconditioner is built?

    % Use tolerance 1e-6 and max iterations 500

    [dg,~,~,iterpcg]=pcg( %YOUR CODE GOES HERE

    

    
    ds=(r2-dg.*s)./g;

    itertime=toc;
    IPM_time=IPM_time+itertime;
    iterPCG=iterPCG+iterpcg;
    
    %% Find steplength
    idg = dg < 0;
    ids = ds < 0;
    alphamax_g = min([1;-g(idg)./dg(idg)]);
    alphamax_s = min([1;-s(ids)./ds(ids)]);
    alpha_g = rho*alphamax_g;
    alpha_s = rho*alphamax_s;
    
    %step
    g = g+alpha_g*dg; 
    s = s+alpha_s*ds;
    
    %% Prepare next iteration
    r1=Atm+s-fAt(fA(g))-apply_Q2(alpha,beta,g);
    mu=dot(g,s)/n;
    
    %print results
    if (n<=2048)
        %Compute the full normal equations matrix for small sizes
        NE = Q + diag(s./g);
        condNE = condest(NE);
        fprintf('%6d   %10.2e %10.2e %7d %12.1E\n',iter,norm(r1)/nAtm,mu,iterpcg,condNE)
    else
        fprintf('%6d   %10.2e %10.2e %7d\n',iter,norm(r1)/nAtm,mu,iterpcg)
    end

    
end

%% Print
fprintf('\nTime: %f\n',IPM_time)
fprintf('IPM iter: %d\n',iter)
fprintf('PCG iter: %d\n',iterPCG)




