function Q = explicit_Q(n,m,CS,alpha,beta)

Nang    = 60; 
angle0  = -90;
ang     = angle0 + 0:(Nang-1)/Nang*180;
AtA = sampling_AtA(n/2,sqrt(n/2),m,ang);
Q = kron([CS.c11^2+CS.c21^2 CS.c11*CS.c12+CS.c21*CS.c22;CS.c11*CS.c12+CS.c21*CS.c22 CS.c12^2+CS.c22^2],AtA);
Q = Q + kron([alpha beta;beta alpha],speye(n/2));