%=====================================================================
%  This Matlab code was developed by
%
%  S. Siltanen, S. Latva-Aijo, M. Lassas (Helsinki University)
%  J. Gondzio, F. Zanetti (Edinburgh University)
%
%  as part of the project
%
%  "Material-separating regularizer for multi-energy X-ray tomography"
%
%=====================================================================

clear
clc
close

%% Choose the size of the problem
%choose 8, 16 or 32

N = 8;


%% Parameters

%regularization parameters
alpha  = 500;             
beta  = 250;

%noise level
noiselevel = 0.01;

% measurement angles
Nang    = 60; 
angle0  = -90;
rotang  = 45; 
ang     = angle0 + 0:(Nang-1)/Nang*180;

%% Attenuation coefficients 

c11     = 1.491; % PVC    30kV  (Low energy)
c12     = 8.561; % Iodine 30kV
c21     = 0.456; % PVC    50kV  (High energy)
c22     = 12.32; % Iodine 50kV

%% load vector g

load(sprintf("g_size%d",N));

%% Generate measurement vector

% Simulate noisy measurements avoiding inverse crime 
m       = apply_Matrix_rotang(c11,c12,c21,c22,g,ang,N,rotang); 
% Add noise/poisson noise
m  = m + noiselevel*max(abs(m(:)))*randn(size(m));

%% Solve the problem

%create struct for preconditioning
CS=struct();
[AtA,rho]=sampling_AtA(N^2,N,m,ang);
CS.e11=alpha+(c11^2+c21^2)*rho;
CS.e12=beta+(c11*c12+c21*c22)*rho;
CS.e22=alpha+(c12^2+c22^2)*rho;
CS.c11 = c11;
CS.c12 = c12;
CS.c21 = c21;
CS.c22 = c22;

%create functions to call A and At
fA = @(x) apply_Operator_A(c11,c12,c21,c22,x,ang,N);
fAt = @(x) apply_Operator_At(c11,c12,c21,c22,x,ang);


% IPM IS CALLED HERE            <=============
g=ipm_xray(fA,fAt,m,2*N^2,alpha,beta,CS);


%% Display the result

g1=g(1:end/2);
g2=g(end/2+1:end);
       
CG1 = reshape(g1,N,N);
CG2 = reshape(g2,N,N);

figure(2)
subplot(1,2,1)
imagesc(CG1);
colormap gray;
axis square;
axis off;
title("Material 1")

% Reconstruction of target2
subplot(1,2,2)
imagesc(CG2);
colormap gray;
axis square;
axis off;
title("Material 2")


