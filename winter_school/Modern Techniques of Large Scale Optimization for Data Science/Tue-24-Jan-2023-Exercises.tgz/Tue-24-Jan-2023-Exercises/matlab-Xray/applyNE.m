function y=applyNE()
% % % % % % % % % % % % % % % % % % % %
% Applies Normal Equations matrix
%
% Q + G^-1*S = \mathcal{A}'*\mathcal{A} + Q2 + G^-1*S
%
% to vector x
% % % % % % % % % % % % % % % % % % % %

% WRITE THE CODE REQUIRED TO APPLY THE NORMAL EQUATIONS
% MATRIX TO A VECTOR X

% THIS WILL BE THE MATRIX THAT IS APPLIED AT EACH 
% ITERATION OF THE PCG METHOD


y = %YOUR CODE GOES HERE

