function [X, y, S]= IPLR_BB(A, b, C, r, S, y)
%% 
%  Implementation of the IPLR-BB algorithm for the solution of matrix completion problems
%  described in
% 
%  S. Bellavia, J. Gondzio, M. Porcelli, 
%  "A relaxed interior point method for low-rank semidefinite programming problems 
%  with applications to matrix completion", Journal of Scientific Computing, 89 (2021), Article 46. 
%  https://arxiv.org/abs/1909.06099
%  
%%
%% Version 21 April 2020
% 
% Licence
% 
% Conditions of use
% Use at your own risk! No guarantee of any kind given or implied.
% 
% Copyright (c) 2020, S. Bellavia, J. Gondzio, M. Porcelli. All rights reserved.
% 
% Redistribution and use of this code in source and binary forms, with or without modification,
% are permitted provided that the following conditions are met: Redistributions of source code must retain 
% the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary 
% form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the 
% documentation and/or other materials provided with the distribution.
% 
% Disclaimer
% This software is provided by the copyright holders and contributors "as is" and any express or implied warranties, 
% including, but nor limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. 
% In no event shall the copyright owner or contributors be liable for any direct, indirect, incidental, special, exemplary, 
% or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or 
% profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort 
% (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.


% ADD DESCRIPTION INPUT OUTPUT

% noiseless case
noise = 0;
update_r = false;
r_upd = 1;

% Interior-Point initial parameters
mu = 1; 
sigma = 0.5;

% maximum number of IP iterations
kmax = 30;
% tolerance for the stopping criterion mu < tol
tol = max(1e-4,0.1*noise);

At = A';
[m, N] = size(A);
n = sqrt(N); %=n1+n2

Id = speye(n);

indr = 0;

% initial (y,S,U) for MATRIX-COMPLETION
%y = 0*ones(m,1);
Utmp = kron(ones(ceil(n/r),1),eye(r,r));
U =  Utmp(1:n,:);
%S = C; %-reshape(At*y,n,n);

% primal feasibility
X = U*U' + mu *Id;
r1 = b - A*(reshape(X,n^2,1));

for k = 1 : kmax
    
    x=[reshape(U,n*r,1);y];
    
    % set parameters for BB
    itmax = 300; toll1 = min(1e-3,mu); toll2 = min(1e-3,mu); Nbmax =20;
    % call the BB gradient solver
    [x, fval, iterBB, ierr, p, normap, Nbb] = gradient_BB_SDP(x, itmax, toll1, Nbmax, ...
                                              n,m,r,mu, A, b, C);
        
    Uold = U; yold = y;
    U = reshape(x(1:n*r),n,r);
    y = x(n*r+1:n*r+m);
    
    Sold = S;
    S = C - reshape(At*y,n,n);
    
    % duality gap
    
    XS = U*(U'*S) + mu* S;
    R2 = mu*Id - XS;
    
    gapnew = norm(R2,'fro');
    
    % start the line-search
    alpha = 1;
    
    deltay = y - yold;
   
    ind_defpos = 0; red = 0;

    while ( ind_defpos == 0 && red < 3 )
        
        [~,pdp] = chol(S);
        
        if pdp == 0
            ind_defpos = 1;
        else
            alpha = 0.25*alpha;
            red = red + 1;
            %  'backtracking'
            
            y = yold + alpha * deltay;
            S = Sold - reshape(At*(alpha*deltay),n,n);
        end
    end
    
    nr1old=norm(r1);
    
    % primal feasibility
    r1 = b - A*(reshape(U*U' + mu *Id,n^2,1));
    nr1 = norm(r1);
    
    % Rank updating/downdating strategy
    if ( indr == 1 && nr1/nr1old > 0.9 )
        indr = -1; 
    else
        indr = 0; 
    end
    
    gap = gapnew;
    
    if red > 0
        U = Uold+alpha*(U-Uold);
        XS = U*(U'*S) + mu* S;
        R2 = mu*Id - XS;
        gapnew = norm(R2,'fro');
    end
    
    fprintf('mu = %4.2e  it_o = %5d, it_BB = %5d, ||grad||_2 = %6.2e,  ||Ax-b||_2 = %6.2e, ||X*S-muI||_F =%8.5e  \n', ...
        mu, k, iterBB, normap, nr1, gap)
    
    if ( mu < tol )
        
        X = U*U' + mu *Id;
        S = C - reshape(At*y,n,n);
        XS = U*(U'*S) + mu* S;
        fprintf('\n IPLR-BB converges:\n\n')
        fprintf('%s %9.8e \n', ' Dual objective function  : b''*y:            ', b'*y)
        fprintf('%s %9.8e \n', ' Primal objective function: trace(C''*X):     ', trace(C'*X))
        fprintf('%s %e \n',    ' dual feasibility:                             ', norm(S-C+reshape(At*y,n,n),'fro'))
        fprintf('     \n',    ' ')
        fprintf('%s %e \n',    ' primal feasibility:                           ', norm(A*reshape(X,n^2,1)-b))
        fprintf('%s %e \n',    ' gap: ||X*S-muI||_F                            ', norm(XS-mu*eye(n),'fro'))
        fprintf('     \n',    ' ')
        fprintf('%s %9d \n', ' Final rank:               ', r)
        fprintf('     \n',    ' ')
               
        return
    else
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % UPDATE/DOWNDATE RANK STRATEGY
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if (nr1/nr1old>0.9  && (normap/sqrt(n*r+m))<1 && indr>=0 && update_r )
            
            % increase the rank
            r = r+r_upd;
            
            % save the current point/mu in case of downdate at the next
            % iteration
            Usave = U;
            ysave = y;
            musave = mu;
            
            % append r_upd new columns to U
            v = Id(:,r-r_upd+1:r);
            U = [U,v];
            
            indr = 1;
            
            fprintf('rank update:   new rank r = %d \n', r)
        end
              
        % UPDATE MU
        if indr == 1
            mu = mu;
        else
            mu = sigma * mu;
        end
        
        if indr == -1
            r = r-r_upd;
            fprintf('rank downdate: new rank r = %d \n', r)
            
            U = Usave;
            y = ysave;
            mu = musave;
            update_r = 0; % in case of downdate, do not update the rank anymore
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % END OF UPDATE/DOWNDATE RANK STRATEGY
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %pause
    end
end   % END OUTER ITER

% OUTPUT without convergence
XS = U*(U'*S) + mu* S;
fprintf('\n IPLR-BB does not converge in kmax iterations:\n\n')
fprintf('%s %9.8e \n', ' Dual objective function: b''*y:               ', b'*y)
fprintf('%s %9.8e \n', ' Primal objective function: trace(C''*X):     ', trace(C'*X))
fprintf('%s %e %e \n', ' Duality gap: trace(C''*X)-b''*y, X\bullet S: ', trace(C'*X)-b'*y, trace(XS))
fprintf('%s %e \n',    ' primal feasibility:                           ', norm(A*reshape(X,n^2,1)-b))
fprintf('%s %e \n',    ' dual feasibility:                             ', norm(S-C+reshape(At*y,n,n),'fro'))
fprintf('%s %e \n',    ' gap: X*S-muI                                  ', norm(XS-mu*eye(n),'fro'))
fprintf('     \n',    ' ')

end















