function [x,fval,k,ierr,p,pnorma,Nbb] = gradient_BB_SDP(x,kmax,toll1,Nbmax,n,m,r,mu, A, b, C)
% Implementation of the nonmonotone Barzilai-Borwein algorithm described in
% Algorithm 2 of the paper
% D. di Serafino, V. Ruggiero, G. Toraldo, and L. Zanni,
% "On the steplength selection in gradient methods for unconstrained
% optimization"
% Applied Mathematics and Computation, 318 (2018), pp. 176 - 195. 
% Recent Trends in Numerical Computations: Theory and Algorithms.
%
% adapted to the nonlinear least squares problem in the IPLR strategy.

[fval,r1,R2,U,S] = funz_BB(x,n,m,r,mu,A, b,C);
p = grad_BB(r1,R2, U,S, mu, A);

M=10;
Nbb=1;    ierr=-1;
precx=x;    fpre=fval;
pnorma=norm(p);   alpha=1;
vettfunz=zeros(1,M+1);   vettfunz(1)=fval;
pnorma0=pnorma;
alpha_min=1.e-10;
alpha_max=1.e5;
vettalpha=alpha_max*ones(5,1);
for k=0:kmax-1

    Mmin=min(k,M)+1;   fmax=max(vettfunz(1:Mmin));
    
    Nb=0;
    x = precx-alpha*p;
    [ft,r1,R2,U,S] = funz_BB(x,n,m,r,mu,A,b,C);
    while (ft >(fmax-(1.d-4)*alpha*pnorma^2))
        alpha=0.5*alpha;
        Nb=Nb+1;
        if (Nb > Nbmax)
            ierr=3;
            return
        end
        x = precx-alpha*p;
        [ft,r1,R2,U,S]=funz_BB(x,n,m,r,mu,A,b,C);
    end
    
    fval=ft;
    
    Nbb=Nb+Nbb;

    precgrad=p;
    p=grad_BB(r1,R2, U,S, mu,A);
    pnorma=norm(p);
    
    if (pnorma< toll1+toll1*pnorma0)
        ierr=1;
        return
    end
    s3=x-precx;
        
    s4=p-precgrad;
    
    z=-precgrad'*s4;
    if z>0
        alpha_1=max(alpha_min,min((-s3'*precgrad)/z, alpha_max));
        alpha_2=max(alpha_min,min((alpha*z)/(norm(s4)^2), alpha_max));
        vettalpha(2:5)=vettalpha(1:4);    vettalpha(1)=alpha_2;
        if alpha_2/alpha_1 < 0.5
            alpha=min(vettalpha);
        else
            alpha=alpha_1;
        end
    else
        alpha=1;
    end
    vettfunz(2:end)=vettfunz(1:M);    vettfunz(1)=fval;
    precx=x; fpre=fval;
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function for BB_p.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [f,r1,R2,U, S] = funz_BB(x,n,m,r,mu, A, b,C)

U=reshape(x(1:n*r),n,r);
X = U*U' + mu *speye(n);
r1 = b - A*(reshape(X,n^2,1));

S = C-reshape(A'*x(n*r+1:n*r+m),n,n);
R2 = mu*speye(n) - X * S;

f=0.5*(norm(r1)^2+norm(R2,'fro')^2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function grad = grad_BB(r1, R2, U, S, mu, A)

[m, N ] = size(A);
n = sqrt(N);
r = size(U,2);
grad = zeros(n*r+m,1);
grad(1:n*r) = prod_J1T_rhs_BB(-r1, -R2, U, S, r, A);
grad(n*r+1:n*r+m) = prod_J22T_rhs_BB(-R2, U, mu, A);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function w = prod_J1T_rhs_BB(x1, X2, U, S, r, A)
% product [J11' J21'] times vector x

% x1 is a vector m x 1
% X2 is a matrix nxn
% beta weight, scalar

% U is a matrix nxr
% Ai are m matrices of dimension nxn
% S is a matrix nxn
[m, N ] = size(A);
n = sqrt(N);


%%%%%%%%%%%%%%%%%%%%%%%%%%

% J11^T * x1
% W1 = zeros(n,r);
% for i = 1:m
%     W1 = W1 + x1(i)*Ai{i}*U;  % <-----------------------
% end
% w1 = 2 * reshape(W1,n*r,1);


w1 = 2 * reshape(reshape(A'*x1,n,n)*U,n*r,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%

% J21'* x2

W2 = X2*(S*U)+ S*(X2'*U);
w2 = reshape(W2,n*r,1);

w = w1+w2;

return
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function w = prod_J22T_rhs_BB(V, U, mu, A)
% product [J22'] times vector v

% V is a matrix nxn

% X is a matrix nxn
% Ai are m matrices of dimension nxn
[m, N ] = size(A);
n = sqrt(N);

X = U*U' + mu *speye(n);
%%%%%%%%%%%%%%%%%%%%%%%%%%

% J22^T * w1
WW = X*V; 
% w = zeros(m,1);
% for i = 1:m
%     w(i) = - trace(Ai{i}*WW);  % <-----------------------
% end
w = - A*reshape(WW, n^2,1);

return

end




