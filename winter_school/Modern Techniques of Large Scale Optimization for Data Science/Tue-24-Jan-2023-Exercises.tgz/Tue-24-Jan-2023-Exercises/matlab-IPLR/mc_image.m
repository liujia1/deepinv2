
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the data set
%% Converts the image into a double variable and assigns the first slice to variable

% YOUR CODE GOES HERE

%% Producing an image with ${\tt p}\%$ of known pixels  by generating $m$ random entries and scaling it by its norm

% YOUR CODE GOES HERE

%% Visualising the matrix of observations
% Matrix with known data
B_part = B_true(Omega);     % generate the vector of observations
A50 = zeros(n1,n2);
A50(Omega) = B_part; %matrix of observation
figure(2)
imshow(uint8(A50))

%% Get data for SDP formulation
[A,b,C] = getInput(B_true, Omega);

%% Define Initial points
% YOUR CODE GOES HERE

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CALL LOWRANK-IP-BB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n Recovering a %.0f x %.0f image of rank %.0f  with %.0f%s randomly missing pixels with IPLR-BB...\n\n', ...
    n1, n2, r, 100*(1-p),'%')


% YOUR CODE GOES HERE


%% Extract solution and analyze the results

normdata = norm(B_part,'fro');

% YOUR CODE GOES HERE


% RESULTS
fprintf('IPLR: The recovered rank is %d\n',r);
fprintf('IPLR: The relative error on Omega is: %d\n', norm(B_part-B_rec(Omega))/norm(B_part))
fprintf('IPLR: The relative recovery error is: %d\n', norm(B_true-B_rec,'fro')/norm(B_true,'fro'))
fprintf('IPLR: PSNR %10.2f\n', %YOUR CODE GOES HERE 

%% Visulise Recovered Image

figure(3)
imshow(uint8(B_rec))



