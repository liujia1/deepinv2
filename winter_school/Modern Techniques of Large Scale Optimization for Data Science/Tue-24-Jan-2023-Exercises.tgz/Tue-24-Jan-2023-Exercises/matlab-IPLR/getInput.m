function [A, b, C] = getInput(B_true, Omega)

% Compute the SDP data

[n1, n2] = size(B_true);


% YOUR CODE GOES HERE


A = generate_constraints(%YOUR CODE GOES HERE;

end

function A = generate_constraints(Omega,n1,n2)
% Compute the constraint matrices Ai's and pack them
% in the matrix A
m = length(Omega);

vj = zeros(2*m,1);
vi = [1:m,1:m]';
e = 0.5*ones(2*m,1);
for l=1:m
    itheta=mod(Omega(l),n1);
    if itheta==0
        itheta=n1;
        jtheta=floor(Omega(l)/n1);
    else
        jtheta=floor(Omega(l)/n1)+1;
    end
    vj(l)=(itheta-1)*(n1+n2)+n1+jtheta;
    vj(l+m)=(n1+(jtheta-1))*(n1+n2)+itheta;
    %theta=sparse(itheta,jtheta,1,n1,n2);
    % Avec(i,:)=reshape(sparse([sparse(n1,n1), theta; theta', sparse(n2,n2)]),(n1+n2)^2,1);
end

n = n1 + n2;
A=sparse(vi,vj,e,m,(n1+n2)^2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
