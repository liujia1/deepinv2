function [x,y,s] = ipdriverQP(c,A,b,Q,tol,maxit,printlevel)
%IPDRIVER    Primal-dual interior-point method.
%
%  This is the driver function of a very simple IPM for solving the
%  quadratic programming problem
%
%    min c'x + 1/2*x'Qx  subject to A*x=b, x>=0,            (1)
%
%  where A has full row rank. In each iteration NEWTONSOLVE[R] is called
%  for solving the linear system of step equations.
%
%  [x,y,s] = ipdriverQP(c,A,b,Q) finds the primal-dual solution x, (y,s) of
%  the quadratic program in form (1). y are the Lagrange multipliers to the
%  equality constraints and s>=0 the Lagrange multipliers to the
%  nonnegativity constraints on x.
%
%  [x,y,s] = ipdriverQP(c,A,b,Q,tol) specifies the termination tolerance.
%  The method terminates when the relative primal residual, the relative
%  dual residual and the duality measure are all below tol.
%  Default: 1e-7.
%
%  [x,y,s] = ipdriverQP(c,A,b,Q,tol,maxit) specifies the maximum number of
%  iterations. Default: 100.
%
%  [x,y,s] = ipdriverQP(c,A,b,Q,tol,maxit,printlevel) sets the printlevel.
%  0: turn off iteration output
%  1: print primal and dual residual and duality measure
%  2: print centering parameter and step length
%  3: print residuals in the solution of the step equations
%  Default: 1

  [m, n] = size(A);
  IPMTT = 0;
    
  % Make sure that b and c are column vectors of dimension m and n.
  if (size(b,2) > 1) b = b'; end
  if (size(c,2) > 1) c = c'; end
  if (~isequal(size(c),[n,1]) || ~isequal(size(b),[m,1]))
    error('problem dimension incorrect');
  end

  % Make sure that A, Q are sparse and b, c are full.
  if (~issparse(A)) A = sparse(A); end
  if (~issparse(Q)) Q = sparse(Q);end
  if (issparse(b)) b = full(b); end
  if (issparse(c)) c = full(c); end

  % Set default values for missing parameters.
  if (nargin < 5 || isempty(tol)) tol = 1e-7; end
  if (nargin < 6 || isempty(maxit)) maxit = 100; end
  if (nargin < 7 || isempty(printlevel)) printlevel = 1; end
  pl = printlevel;

  % ********************************************************************
  % Initialization
  % ==============  
  
  %YOUR CODE GOES HERE
  