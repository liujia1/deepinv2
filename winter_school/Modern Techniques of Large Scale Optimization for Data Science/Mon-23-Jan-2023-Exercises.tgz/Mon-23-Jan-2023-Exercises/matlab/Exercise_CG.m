clear;clc;

%% CHOOSE WHICH EXAMPLE TO RUN
% 1, 2 or 3

example_ID = 1; 


%% MATRIX IS BUILT

switch example_ID
    case 1
        Matrix = gallery('wathen',2,2);
    case 2
        Matrix = gallery('wathen',10,10);
    case 3
        Matrix = gallery('wathen',20,20);
end

n = size(Matrix,1);
fprintf("Example %d\n",example_ID);
fprintf("SPD matrix of size %d\n\n",n);

%% PRECONDITIONERS ARE BUILT

M1 = spdiags(diag(Matrix),0,n,n);
Prec_1 = @(x) M1\x;

M2 = ichol(Matrix);
Prec_2 = @(x) M2'\(M2\x);

M3 = ichol(Matrix,struct('type','ict','droptol',1e-3));
Prec_3 = @(x) M3'\(M3\x);

%% GENERATE RIGHT-HAND SIDE

rhs = rand(n,1);
rhs = rhs/norm(rhs);

%% MODIFY THE CODE IN THIS SECTION      <=============

% Use 'help pcg' to understand how 'pcg' should be called.
% Use a tolerance of 1e-6 and maximum number of iterations of 200



tic;
% call pcg without preconditioner:
[~,~,~,iter_0,res_0] = pcg( %YOUR CODE GOES HERE
time_0=toc;

tic;
% call pcg using Prec_1 as preconditioner:
[~,~,~,iter_1,res_1] = pcg( %YOUR CODE GOES HERE
time_1=toc;

tic;
% call pcg using Prec_2 as preconditioner:
[~,~,~,iter_2,res_2] = pcg( %YOUR CODE GOES HERE
time_2=toc;

tic;
% call pcg using Prec_3 as preconditioner:
[~,~,~,iter_3,res_3] = pcg( %YOUR CODE GOES HERE
time_3=toc;





%% PRINT THE RESULTS
fprintf("PCG without preconditioner:\t\t\t %3d iterations and %.1e seconds\t\tk(A)      = %7.2f\n",iter_0,time_0,condest(Matrix))
fprintf("PCG with diagonal preconditioner:\t\t %3d iterations and %.1e seconds\t\tk(P^-1 A) = %7.2f\n",iter_1,time_1,condest(M1\Matrix))
fprintf("PCG with incomplete Cholesky:\t\t\t %3d iterations and %.1e seconds\t\tk(P^-1 A) = %7.2f\n",iter_2,time_2,condest(M2'\(M2\Matrix)))
fprintf("PCG with incomplete Cholesky with droptol:\t %3d iterations and %.1e seconds\t\tk(P^-1 A) = %7.2f\n",iter_3,time_3,condest(M3'\(M3\Matrix)))

fprintf("\nAre the times proportional to the number of iterations?\nCan you think of a reason why?\n")


%% PLOT THE RESIDUALS
figure(1)
semilogy(0:iter_0,res_0,'k','LineWidth',3)
hold on
semilogy(0:iter_1,res_1,'r','LineWidth',3)
semilogy(0:iter_2,res_2,'b','LineWidth',3)
semilogy(0:iter_3,res_3,'g','LineWidth',3)
hold off
xlabel('Iteration')
ylabel('Residual')
legend('No prec','Diagonal','ichol','ichol with droptol')





