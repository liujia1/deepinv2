% Use ipdriver to solve
%
% min c'x subject to A*x=b, x>=0,
%
A = [1 1 -1 0; 3 1 0 -1];
b = [3 6]';
c = [2 1 0 0]';

[x,y,s] = ipdriver(c,A,b);

